# Control de préstamo de portátiles

Aplicación web local y en español para llevar inventario de portátiles, registrar préstamos y anotar devoluciones.

## Uso

1. Extrae el archivo ZIP.
2. Abre `index.html` con un navegador moderno (Chrome, Edge o Firefox).
3. Registra los equipos por su código de inventario.
4. Registra cada préstamo con la identificación de la persona y la fecha acordada de devolución.
5. Usa **Registrar devolución** al recibir un equipo. Si escribes que está dañado o requiere reparación, quedará fuera de servicio.
6. Usa **Exportar copia JSON** para guardar un respaldo. Puedes importarlo en el mismo navegador o en otro equipo.

## Alcance

Los datos se guardan en el almacenamiento local del navegador; no se sincronizan entre equipos ni usuarios. No hay cuentas, permisos ni avisos automáticos. La aplicación no determina responsabilidades por daños ni implementa sanciones o renovaciones. Esas reglas deben ser definidas por el centro.

No se incluyen dependencias ni se requiere instalación.
